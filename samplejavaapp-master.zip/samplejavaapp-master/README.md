Sample Java Applicaiton V3.6.6
